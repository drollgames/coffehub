const Discord = require("discord.js");
// constante da livraria do discord

const Client = new Discord.Client();
// criar client para o bot

require("./config.js");
// configurações do bot

require("./console.js");
//console do app

client.on() => {
    console.log("Bot Iniciadodo...");
    // bot iniciado
    // ...
});

client.login(processo.env.TOKEN)
/*ligar o bot, caso código consiga acessar o token

Para colocar o TOKEN em config.json
troque para (config.token)*/