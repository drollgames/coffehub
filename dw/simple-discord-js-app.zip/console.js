/*
console simples
*/

console.log("iniciando aplicação...");
//app is starting

console.log("carregando arquivos!");
//carregando arquivos