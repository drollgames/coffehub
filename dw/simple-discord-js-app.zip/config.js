const config = require("./config.json");
// configurações do json

// ...